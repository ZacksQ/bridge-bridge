
# 桩基计算
## 上传地层信息表
**URL:** `http://218.94.57.151:8089/pile-len/calc/stratum/upload`

**Type:** `POST`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 上传地层信息表



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
file|file||true|-


**Request-example:**
```
curl -X POST -i http://218.94.57.151:8089/pile-len/calc/stratum/upload
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 194,
  "resultNote": "xsnjfy",
  "resultErrorMap": {
    "mapKey": "2hcod9"
  },
  "data": {}
}
```

## 查看地层信息
**URL:** `http://218.94.57.151:8089/pile-len/calc/stratum/list`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 查看地层信息





**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/stratum/list
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|array|响应结果返回|-
└─id|int32|岩土ID|-
└─rid|string|线路ID|-
└─soilNumber|string|岩土编号|-
└─soilName|string|岩土名称|-
└─liquidLimit|double|液限%|-
└─liquidIndex|double|液性指数|-
└─fa0|int32|地基承载力特征值kpa|-
└─qik|int32|桩侧土摩阻力标准值kpa|-
└─raj|double|饱和单轴抗压强度Mpa|-
└─permeable|boolean|透水性|-
└─k2|double|K2值|-
└─softSoil|boolean|是否软弱层|-
└─description|string|土层描述|-

**Response-example:**
```
{
  "code": 670,
  "resultNote": "2a1p5n",
  "resultErrorMap": {
    "mapKey": "6xryg7"
  },
  "data": [
    {
      "id": 516,
      "rid": "156",
      "soilNumber": "etxt3i",
      "soilName": "marget.bartoletti",
      "liquidLimit": 64.41,
      "liquidIndex": 64.09,
      "fa0": 938,
      "qik": 663,
      "raj": 53.56,
      "permeable": true,
      "k2": 17.10,
      "softSoil": true,
      "description": "xz68q7"
    }
  ]
}
```

## 新增/更改地层信息
**URL:** `http://218.94.57.151:8089/pile-len/calc/stratum/update`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 新增/更改地层信息




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
id|int32|岩土ID(新增时为null)|false|-
soilNumber|string|岩土编号|false|-
soilName|string|岩土名称|false|-
liquidLimit|double|液限%|false|-
liquidIndex|double|液性指数|false|-
fa0|int32|地基承载力特征值kpa|false|-
qik|int32|桩侧土摩阻力标准值kpa|false|-
raj|double|饱和单轴抗压强度Mpa|false|-
permeable|boolean|透水性|false|-
k2|double|K2值|false|-
softSoil|boolean|是否软弱层|false|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/pile-len/calc/stratum/update --data '{
  "id": 464,
  "soilNumber": "vxini7",
  "soilName": "marget.bartoletti",
  "liquidLimit": 45.26,
  "liquidIndex": 9.02,
  "fa0": 26,
  "qik": 439,
  "raj": 44.87,
  "permeable": true,
  "k2": 15.43,
  "softSoil": true
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 381,
  "resultNote": "ig5z5b",
  "resultErrorMap": {
    "mapKey": "4th8uh"
  },
  "data": {}
}
```

## 删除一行地层信息
**URL:** `http://218.94.57.151:8089/pile-len/calc/stratum/delete`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 删除一行地层信息




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
id|int32|No comments found.|false|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/pile-len/calc/stratum/delete --data '{
  "id": 186
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 355,
  "resultNote": "joga8z",
  "resultErrorMap": {
    "mapKey": "v763ky"
  },
  "data": {}
}
```

## 查看钻孔信息
**URL:** `http://218.94.57.151:8089/pile-len/calc/drill/list`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 查看钻孔信息





**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/drill/list
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|array|响应结果返回|-
└─drillId|int32|钻孔ID|-
└─drillNum|string|钻孔编号|-
└─pileNumber|string|钻孔桩号|-
└─imgFileId|int32|预览图片ID|-

**Response-example:**
```
{
  "code": 375,
  "resultNote": "5yn5ox",
  "resultErrorMap": {
    "mapKey": "reo8ze"
  },
  "data": [
    {
      "drillId": 957,
      "drillNum": "p2zjd7",
      "pileNumber": "kr0dbd",
      "imgFileId": 979
    }
  ]
}
```

## 上传孔位桩号
**URL:** `http://218.94.57.151:8089/pile-len/calc/hole-list/upload`

**Type:** `POST`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 上传孔位桩号



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
file|file||true|-


**Request-example:**
```
curl -X POST -i http://218.94.57.151:8089/pile-len/calc/hole-list/upload
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 65,
  "resultNote": "57urpu",
  "resultErrorMap": {
    "mapKey": "3w3p3j"
  },
  "data": {}
}
```

## 上传单孔信息表（分片上传，支持压缩包）&lt;&gt;覆盖时填写drillPile&lt;/&gt;
**URL:** `http://218.94.57.151:8089/pile-len/calc/hole-info/upload`

**Type:** `POST`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 上传单孔信息表（分片上传，支持压缩包）
<>覆盖时填写drillPile</>



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
drillId|int32|钻孔ID|false|-
filename|string|文件名|false|-
file|file|文件|true|-


**Request-example:**
```
curl -X POST -i http://218.94.57.151:8089/pile-len/calc/hole-info/upload --data 'filename=marget.bartoletti&drillId=812'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 31,
  "resultNote": "d102tb",
  "resultErrorMap": {
    "mapKey": "6j69yt"
  },
  "data": {}
}
```

## 轮询获取单孔文件解析进度
**URL:** `http://218.94.57.151:8089/pile-len/calc/upload/progress`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 轮询获取单孔文件解析进度



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
taskId|string|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/upload/progress?taskId=156
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 61,
  "resultNote": "5v9r00",
  "resultErrorMap": {
    "mapKey": "g6mrow"
  },
  "data": {}
}
```

## 查看地质情况
**URL:** `http://218.94.57.151:8089/pile-len/calc/geology/view`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 查看地质情况



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
imgFileId|int32|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/geology/view?imgFileId=657
```

**Response-example:**
```
Return void.
```

## 删除一行单孔信息
**URL:** `http://218.94.57.151:8089/pile-len/calc/hole/delete`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 删除一行单孔信息



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
drillId|int32|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/hole/delete?drillId=792
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 205,
  "resultNote": "jxauq1",
  "resultErrorMap": {
    "mapKey": "vuow9y"
  },
  "data": {}
}
```

## 查看桩基桥梁分组列表
**URL:** `http://218.94.57.151:8089/pile-len/calc/bridge/group`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 查看桩基桥梁分组列表





**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/bridge/group
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|array|响应结果返回|-
└─groupId|int32|分组桥梁ID|-
└─groupName|string|分组桥梁名称|-

**Response-example:**
```
{
  "code": 205,
  "resultNote": "zv2wsm",
  "resultErrorMap": {
    "mapKey": "yutaml"
  },
  "data": [
    {
      "groupId": 198,
      "groupName": "marget.bartoletti"
    }
  ]
}
```

## 保存桥梁分组名称
**URL:** `http://218.94.57.151:8089/pile-len/calc/group/save`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 保存桥梁分组名称



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
groupName|string|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/group/save?groupName=marget.bartoletti
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|int32|响应结果返回|-

**Response-example:**
```
{
  "code": 403,
  "resultNote": "vj5pk4",
  "resultErrorMap": {
    "mapKey": "y77zo4"
  },
  "data": 98
}
```

## 修改桥梁分组名称
**URL:** `http://218.94.57.151:8089/pile-len/calc/group/change`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 修改桥梁分组名称



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
groupId|int32|No comments found.|true|-
groupName|string|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/group/change?groupId=925&groupName=marget.bartoletti
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|string|响应结果返回|-

**Response-example:**
```
{
  "code": 883,
  "resultNote": "b9pp9o",
  "resultErrorMap": {
    "mapKey": "eneghf"
  },
  "data": "ia9q1o"
}
```

## 删除桥梁分组
**URL:** `http://218.94.57.151:8089/pile-len/calc/group/delete`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 删除桥梁分组




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
idList|array|No comments found.|true|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/pile-len/calc/group/delete --data '{
  "idList": [
    649
  ]
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 176,
  "resultNote": "a95bgl",
  "resultErrorMap": {
    "mapKey": "d13c40"
  },
  "data": {}
}
```

## 查看桥梁分组基本信息
**URL:** `http://218.94.57.151:8089/pile-len/calc/group/base-info`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 查看桥梁分组基本信息



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
groupId|int32|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/group/base-info?groupId=750
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-
└─groupId|int32|分组ID|-
└─groupName|string|分组名称|-
└─centerPileNo|string|中桩桩号|-
└─spanComb|string|跨径组合|-
└─pierLenMore|int32|桥墩长度富余|-
└─abutLenMore|int32|桥台长度富余|-
└─pierCarryMore|int32|桥墩承载力富余|-
└─abutCarryMore|int32|桥台承载力富余|-
└─basicList|array|桩基信息|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─pileInfoId|int32|No comments found.|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─pierNo|string|墩台编号|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─pileTopCoForce|int32|桩顶反力|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─pileDiameter|double|桩基直径|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─pileTopHigh|double|桩顶高程|-

**Response-example:**
```
{
  "code": 967,
  "resultNote": "lpa6sq",
  "resultErrorMap": {
    "mapKey": "22gjzg"
  },
  "data": {
    "groupId": 731,
    "groupName": "marget.bartoletti",
    "centerPileNo": "rgmngd",
    "spanComb": "iwtfnu",
    "pierLenMore": 762,
    "abutLenMore": 983,
    "pierCarryMore": 32,
    "abutCarryMore": 173,
    "basicList": [
      {
        "pileInfoId": 71,
        "pierNo": "dtxgr1",
        "pileTopCoForce": 285,
        "pileDiameter": 47.98,
        "pileTopHigh": 74.01
      }
    ]
  }
}
```

## 判断跨径桩基表
**URL:** `http://218.94.57.151:8089/pile-len/calc/group/span`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 判断跨径桩基表



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
spanComb|string|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/group/span?spanComb=z328mo
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|array|响应结果返回|-
└─pileInfoId|int32|No comments found.|-
└─pierNo|string|墩台编号|-
└─pileTopCoForce|int32|桩顶反力|-
└─pileDiameter|double|桩基直径|-
└─pileTopHigh|double|桩顶高程|-

**Response-example:**
```
{
  "code": 39,
  "resultNote": "g8pi0e",
  "resultErrorMap": {
    "mapKey": "6bqk6c"
  },
  "data": [
    {
      "pileInfoId": 698,
      "pierNo": "uf4tis",
      "pileTopCoForce": 130,
      "pileDiameter": 5.75,
      "pileTopHigh": 91.23
    }
  ]
}
```

## 上传桩基信息表
**URL:** `http://218.94.57.151:8089/pile-len/calc/pile/upload`

**Type:** `POST`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 上传桩基信息表



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
file|file||true|-
groupId|int32|分组ID|false|-


**Request-example:**
```
curl -X POST -i http://218.94.57.151:8089/pile-len/calc/pile/upload --data 'groupId=722'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 288,
  "resultNote": "3vvgih",
  "resultErrorMap": {
    "mapKey": "w221ac"
  },
  "data": {}
}
```

## 保存桥梁分组基本信息
**URL:** `http://218.94.57.151:8089/pile-len/calc/group/base-info/save`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 保存桥梁分组基本信息




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
groupId|int32|分组ID|false|-
centerPileNo|string|中桩桩号|true|-
spanComb|string|跨径组合|true|-
pierLenMore|int32|桥墩长度富余|false|-
abutLenMore|int32|桥台长度富余|false|-
pierCarryMore|int32|桥墩承载力富余|false|-
abutCarryMore|int32|桥台承载力富余|false|-
basicList|array|桩基信息|true|-
└─pileInfoId|int32|No comments found.|false|-
└─pierNo|string|墩台编号|false|-
└─pileTopCoForce|int32|桩顶反力|false|-
└─pileDiameter|double|桩基直径|false|-
└─pileTopHigh|double|桩顶高程|false|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/pile-len/calc/group/base-info/save --data '{
  "groupId": 262,
  "centerPileNo": "fidmv1",
  "spanComb": "l2m1kq",
  "pierLenMore": 487,
  "abutLenMore": 22,
  "pierCarryMore": 131,
  "abutCarryMore": 13,
  "basicList": [
    {
      "pileInfoId": 356,
      "pierNo": "n5ec6l",
      "pileTopCoForce": 57,
      "pileDiameter": 17.61,
      "pileTopHigh": 39.75
    }
  ]
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 476,
  "resultNote": "a3unl3",
  "resultErrorMap": {
    "mapKey": "y7rliz"
  },
  "data": {}
}
```

## 查看桥梁分组结果汇总
**URL:** `http://218.94.57.151:8089/pile-len/calc/group/result`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 查看桥梁分组结果汇总



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
groupId|int32|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/group/result?groupId=92
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|array|响应结果返回|-
└─id|int32|No comments found.|-
└─groupId|int32|No comments found.|-
└─pierNo|string|墩台编号|-
└─pierPileNo|double|墩台桩号|-
└─length|double|计算桩长|-
└─suggestLen|int32|建议桩长|-
└─corrDrillNum|string|对应孔号|-
└─warnNote|string|异常情况|-

**Response-example:**
```
{
  "code": 533,
  "resultNote": "emelez",
  "resultErrorMap": {
    "mapKey": "6bcabg"
  },
  "data": [
    {
      "id": 105,
      "groupId": 314,
      "pierNo": "9vuxt7",
      "pierPileNo": 4.39,
      "length": 95.12,
      "suggestLen": 916,
      "corrDrillNum": "y4iy9c",
      "warnNote": "21sfer"
    }
  ]
}
```

## 修改用孔
**URL:** `http://218.94.57.151:8089/pile-len/calc/change/hole`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 修改用孔




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
groupId|int32|分组ID|false|-
pierNo|string|墩台编号|false|-
summaryId|int32|汇总结果ID(新增记录后修改用孔为0)|false|-
corrDrillNum|string|对应孔号|false|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/pile-len/calc/change/hole --data '{
  "groupId": 181,
  "pierNo": "p7c2kk",
  "summaryId": 239,
  "corrDrillNum": "i4y6zt"
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 867,
  "resultNote": "v6wsab",
  "resultErrorMap": {
    "mapKey": "djixnm"
  },
  "data": {}
}
```

## 删除一行结果汇总
**URL:** `http://218.94.57.151:8089/pile-len/calc/summary/delete`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 删除一行结果汇总



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
summaryId|int32|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/summary/delete?summaryId=295
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 609,
  "resultNote": "a2lj7d",
  "resultErrorMap": {
    "mapKey": "21ust8"
  },
  "data": {}
}
```

## 查看桩长结算汇总孔号
**URL:** `http://218.94.57.151:8089/pile-len/calc/summary/hole`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 查看桩长结算汇总孔号



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
groupId|int32|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/summary/hole?groupId=122
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|array|响应结果返回|-
└─groupId|int32|分组桥梁ID|-
└─pierNo|string|墩号|-
└─summaryId|int32|汇总结果ID|-
└─drillNum|string|对应孔号|-

**Response-example:**
```
{
  "code": 452,
  "resultNote": "hrvoph",
  "resultErrorMap": {
    "mapKey": "wiycjn"
  },
  "data": [
    {
      "groupId": 612,
      "pierNo": "ju7t4n",
      "summaryId": 745,
      "drillNum": "5jkm0k"
    }
  ]
}
```

## 桩长计算表
**URL:** `http://218.94.57.151:8089/pile-len/calc/result/table`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 桩长计算表



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
groupId|int32|No comments found.|true|-
pierNo|string|No comments found.|true|-
summaryId|int32|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/result/table?groupId=537&pierNo=582vl1&summaryId=400
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-
└─id|int32|summaryId|-
└─corrDrillNum|string|对应孔号|-
└─pileLength|int32|桩长|-
└─um|double|U(m)|-
└─ap|double|Ap（m2）|-
└─m0|double|m0|-
└─lamda|double|lamda|-
└─fa0|int32|地基承载力特征值kpa|-
└─k2|double|K2值|-
└─r2|double|γ2|-
└─hm|double|h(m)|-
└─qr|double|qr（kPa）|-
└─t0|double|t0|-
└─bottomLimit|int32|桩端限值|-
└─ttn|int32|桩顶至孔底总高度|-
└─tsf|double|总分段摩阻|-
└─rsat|double|γsat|-
└─permeable|int32|透水性（1透水0不透水）|-
└─soil|string|桩至土名称|-
└─plies|int32|桩端层数|-
└─bearingCapacity|double|上部承载力|-
└─pileTopCoForce|int32|桩顶反力|-
└─pileDiameter|double|直径|-
└─pileTopHigh|double|桩顶标高|-
└─pileBottomHigh|double|桩底标高|-
└─carryMore|int32|承载力富余|-
└─lenMore|int32|长度富余|-
└─carryRatioStr|string|桩承力比例|-
└─slenderRatio|double|长细比|-
└─note|string|表格注|-
└─detailList|array|土层详情|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─sn|int32|No comments found.|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─soilNumber|string|土层编号|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─soilName|string|土层名称|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─height|double|层底标高|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─thickness|double|厚度|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─qik|int32|qik|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─fa0|int32|[fa0]|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─basePiece|double|基础分段|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─segFrict|double|分段摩阻|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─k2|double|K2值|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─rsat|double|γsat|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─permeable|int32|透水性（1透水0不透水-1-）|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─bottomLayer|int32|桩端层位（0：↓ 1：←  -1：↑）|-

**Response-example:**
```
{
  "code": 486,
  "resultNote": "mpw5ph",
  "resultErrorMap": {
    "mapKey": "vpgxob"
  },
  "data": {
    "id": 995,
    "corrDrillNum": "zoyohm",
    "pileLength": 357,
    "um": 88.49,
    "ap": 39.74,
    "m0": 72.22,
    "lamda": 66.48,
    "fa0": 231,
    "k2": 73.89,
    "r2": 59.33,
    "hm": 81.79,
    "qr": 85.91,
    "t0": 57.98,
    "bottomLimit": 10,
    "ttn": 227,
    "tsf": 45.32,
    "rsat": 97.01,
    "permeable": 846,
    "soil": "ias8z5",
    "plies": 265,
    "bearingCapacity": 65.63,
    "pileTopCoForce": 120,
    "pileDiameter": 33.40,
    "pileTopHigh": 32.60,
    "pileBottomHigh": 7.89,
    "carryMore": 722,
    "lenMore": 577,
    "carryRatioStr": "lc3jj8",
    "slenderRatio": 2.89,
    "note": "ewm6wr",
    "detailList": [
      {
        "sn": 775,
        "soilNumber": "9hvmfz",
        "soilName": "marget.bartoletti",
        "height": 45.33,
        "thickness": 44.53,
        "qik": 630,
        "fa0": 597,
        "basePiece": 59.11,
        "segFrict": 69.81,
        "k2": 35.20,
        "rsat": 17.33,
        "permeable": 978,
        "bottomLayer": 830
      }
    ]
  }
}
```

## 更改桩长表
**URL:** `http://218.94.57.151:8089/pile-len/calc/table/change`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 更改桩长表




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
groupId|int32|分组ID|false|-
pierNo|string|墩台ID|false|-
summaryId|int32|汇总结果ID|false|-
sn|int32|更改土层sn|false|-
columnName|string|更改列名|false|-
cellValue|string|更改后值|false|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/pile-len/calc/table/change --data '{
  "groupId": 184,
  "pierNo": "7zbzaz",
  "summaryId": 740,
  "sn": 364,
  "columnName": "marget.bartoletti",
  "cellValue": "ljhs34"
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 588,
  "resultNote": "71n5z1",
  "resultErrorMap": {
    "mapKey": "kdbad7"
  },
  "data": {}
}
```

## 上传Access数据库文件
**URL:** `http://218.94.57.151:8089/pile-len/calc/mdb/upload`

**Type:** `POST`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 上传Access数据库文件



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
file|file||true|-


**Request-example:**
```
curl -X POST -i http://218.94.57.151:8089/pile-len/calc/mdb/upload
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 577,
  "resultNote": "txx7kd",
  "resultErrorMap": {
    "mapKey": "9iqrg2"
  },
  "data": {}
}
```

## 获取Access数据库文件名
**URL:** `http://218.94.57.151:8089/pile-len/calc/mdb/filename`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 获取Access数据库文件名





**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/mdb/filename
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 486,
  "resultNote": "gms33k",
  "resultErrorMap": {
    "mapKey": "aijjyr"
  },
  "data": {}
}
```

## 查看单孔信息表
**URL:** `http://218.94.57.151:8089/pile-len/calc/drill/detail`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 查看单孔信息表



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
drillId|int32|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/drill/detail?drillId=816
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-
└─drillId|int32|No comments found.|-
└─drillNum|string|钻孔编号|-
└─drillHeight|double|孔口高程|-
└─pileNumber|double|孔位桩号|-
└─offsetStr|string|偏移量|-
└─soilList|array|土层信息|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─soilId|int32|No comments found.|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─soilNumber|string|土层编号|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─soilName|string|土层名称|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─depth|double|层底深度|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─thickness|double|层底标高|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─height|double|层底高程|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─description|string|土层描述|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─qik|int32|qik|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─fa0|int32|[fa0]|-
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;└─remarks|string|备注|-

**Response-example:**
```
{
  "code": 665,
  "resultNote": "1gy94j",
  "resultErrorMap": {
    "mapKey": "so9xjz"
  },
  "data": {
    "drillId": 577,
    "drillNum": "m1s0xh",
    "drillHeight": 5.63,
    "pileNumber": 68.21,
    "offsetStr": "uiz7p6",
    "soilList": [
      {
        "soilId": 972,
        "soilNumber": "igk9tf",
        "soilName": "marget.bartoletti",
        "depth": 50.18,
        "thickness": 48.44,
        "height": 92.38,
        "description": "9vctfz",
        "qik": 322,
        "fa0": 906,
        "remarks": "voghvt"
      }
    ]
  }
}
```

## 更改单孔信息表
**URL:** `http://218.94.57.151:8089/pile-len/calc/drill/change`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 更改单孔信息表




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
drillId|int32|钻孔ID(必传)|false|-
soilId|int32|更改土层行Id(修改孔口高程及里程时为null)|false|-
columnName|string|更改列名|false|-
cellValue|string|更改后值|false|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/pile-len/calc/drill/change --data '{
  "drillId": 884,
  "soilId": 575,
  "columnName": "marget.bartoletti",
  "cellValue": "e8xi44"
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 230,
  "resultNote": "x9dozm",
  "resultErrorMap": {
    "mapKey": "3ps50m"
  },
  "data": {}
}
```

## 导出桩长计算表
**URL:** `http://218.94.57.151:8089/pile-len/calc/result/export`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 导出桩长计算表



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
groupId|int32|No comments found.|true|-
pierNo|string|No comments found.|true|-
summaryId|int32|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/result/export?summaryId=350&pierNo=5rvhjs&groupId=445
```

**Response-example:**
```
Return void.
```

## 下载桩长计算模板表
**URL:** `http://218.94.57.151:8089/pile-len/calc/result/template`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 下载桩长计算模板表





**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/pile-len/calc/result/template
```

**Response-example:**
```
Return void.
```

