
# 登录控制类
## 登录
**URL:** `http://218.94.57.151:8089/login`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 登录




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
username|string|No comments found.|false|-
password|string|No comments found.|false|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/login --data '{
  "username": "lashawn.friesen",
  "password": "kfcq86"
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 911,
  "resultNote": "1pndbv",
  "resultErrorMap": {
    "mapKey": "w2kkj6"
  },
  "data": {}
}
```

## 登出
**URL:** `http://218.94.57.151:8089/logout`

**Type:** `POST`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 登出





**Request-example:**
```
curl -X POST -i http://218.94.57.151:8089/logout
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 964,
  "resultNote": "rnhy8u",
  "resultErrorMap": {
    "mapKey": "c767n8"
  },
  "data": {}
}
```

## 注册
**URL:** `http://218.94.57.151:8089/register`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 注册




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
telephone|string|手机号|false|-
sms|string|邮箱验证码|false|-
mail|string|邮箱|true|-
password|string|sha256加密后密码|true|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/register --data '{
  "telephone": "620-219-4942",
  "sms": "p2uu3o",
  "mail": "nvaekp",
  "password": "bufeaw"
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 784,
  "resultNote": "c75khw",
  "resultErrorMap": {
    "mapKey": "1ui7fd"
  },
  "data": {}
}
```

## 发送邮箱验证码
**URL:** `http://218.94.57.151:8089/sendSMS`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 发送邮箱验证码



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
mail|string|请求类|true|-
type|int32|No comments found.|false|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/sendSMS?mail=邮箱必填&type=1
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 793,
  "resultNote": "wj4kn0",
  "resultErrorMap": {
    "mapKey": "slzj2h"
  },
  "data": {}
}
```

## 忘记密码
**URL:** `http://218.94.57.151:8089/forgotPassword`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 忘记密码




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
sms|string|邮箱验证码|false|-
mail|string|邮箱|true|-
newPassword|string|No comments found.|true|-
confirmPassword|string|No comments found.|true|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/forgotPassword --data '{
  "sms": "nmx76k",
  "mail": "ftd870",
  "newPassword": "bp614x",
  "confirmPassword": "ym28nj"
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 642,
  "resultNote": "tct0ta",
  "resultErrorMap": {
    "mapKey": "9yd6p0"
  },
  "data": {}
}
```

