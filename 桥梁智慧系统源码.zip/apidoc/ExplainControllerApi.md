
# 桥梁说明概览
## 列表
**URL:** `http://218.94.57.151:8089/bridge/explain/list`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 列表





**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/bridge/explain/list
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|array|响应结果返回|-
└─id|int32|No comments found.|-
└─name|string|项目名称|-
└─province|int32|省份|-
└─highwayClassify|int32|公路分级|-
└─specialUpper|int32|特殊上部结构|-

**Response-example:**
```
{
  "code": 918,
  "resultNote": "f30gel",
  "resultErrorMap": {
    "mapKey": "pugjpd"
  },
  "data": [
    {
      "id": 545,
      "name": "nicolette.bernhard",
      "province": 469,
      "highwayClassify": 100,
      "specialUpper": 823
    }
  ]
}
```

## 新增
**URL:** `http://218.94.57.151:8089/bridge/explain/add`

**Type:** `POST`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 新增



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
name|string|项目名称|true|-
province|int32|省份|false|-
highwayClassify|int32|公路分级|false|-
specialUpper|int32|特殊上部结构|false|-
file|file|文件|true|-


**Request-example:**
```
curl -X POST -i http://218.94.57.151:8089/bridge/explain/add --data 'highwayClassify=422&specialUpper=590&province=101&name=nicolette.bernhard'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 975,
  "resultNote": "7hzthr",
  "resultErrorMap": {
    "mapKey": "k50r9b"
  },
  "data": {}
}
```

## 文档说明下载
**URL:** `http://218.94.57.151:8089/bridge/explain/download`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 文档说明下载



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
id|int32|No comments found.|false|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/bridge/explain/download?id=89
```

**Response-example:**
```
Return void.
```

