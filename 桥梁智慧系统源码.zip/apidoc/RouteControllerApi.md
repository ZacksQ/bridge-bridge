
# 路线管理
## 路线列表
**URL:** `http://218.94.57.151:8089/route/list`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 路线列表




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
pageNum|int32|页数|false|-
pageSize|int32|每页记录数|false|-
pname|string|No comments found.|false|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/route/list --data '{
  "pageNum": 140,
  "pageSize": 10,
  "pname": "nicolette.bernhard"
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|array|响应结果返回|-
└─rid|string|路线唯一码|-
└─pname|string|工程名称|-
└─rname|string|路线名称|-
└─type|int32|路线编号|-
└─curRid|boolean|是否为当前线路（当前线路进入项目按钮置灰）|-

**Response-example:**
```
{
  "code": 42,
  "resultNote": "h7an0v",
  "resultErrorMap": {
    "mapKey": "qyu4av"
  },
  "data": [
    {
      "rid": "47",
      "pname": "nicolette.bernhard",
      "rname": "nicolette.bernhard",
      "type": 740,
      "curRid": true
    }
  ]
}
```

## 新建/编辑线路
**URL:** `http://218.94.57.151:8089/route/add`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 新建/编辑线路




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
rid|string|项目ID 新建时为空）|false|-
pname|string|项目全称|true|-
rname|string|路线名称|true|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/route/add --data '{
  "rid": "47",
  "pname": "nicolette.bernhard",
  "rname": "nicolette.bernhard"
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 921,
  "resultNote": "li8n0j",
  "resultErrorMap": {
    "mapKey": "w8fj4c"
  },
  "data": {}
}
```

## 删除线路
**URL:** `http://218.94.57.151:8089/route/delete`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 删除线路




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
ridList|array|No comments found.|true|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/route/delete --data '{
  "ridList": [
    "gi2cfd"
  ]
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 756,
  "resultNote": "d6pofd",
  "resultErrorMap": {
    "mapKey": "4pcokp"
  },
  "data": {}
}
```

## 线路切换
**URL:** `http://218.94.57.151:8089/route/switch`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 线路切换



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
rid|string|No comments found.|true|-


**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/route/switch?rid=47
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 321,
  "resultNote": "q9i5rw",
  "resultErrorMap": {
    "mapKey": "pw7erl"
  },
  "data": {}
}
```

## 路线提资文件上传（多文件上传）
**URL:** `http://218.94.57.151:8089/route/file/upload`

**Type:** `POST`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 路线提资文件上传（多文件上传）



**Query-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
files|file||true|-


**Request-example:**
```
curl -X POST -i http://218.94.57.151:8089/route/file/upload
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 887,
  "resultNote": "r3n7dn",
  "resultErrorMap": {
    "mapKey": "s12n9o"
  },
  "data": {}
}
```

## 路线提资查看
**URL:** `http://218.94.57.151:8089/route/file/list`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 路线提资查看





**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/route/file/list
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-
└─pqxFileName|string|平曲线文件名|-
└─sqxFileName|string|竖曲线文件名|-
└─cgFileName|string|超高文件名|-
└─dmxFileName|string|地面线文件名|-

**Response-example:**
```
{
  "code": 933,
  "resultNote": "gh1jwc",
  "resultErrorMap": {
    "mapKey": "a4fvy1"
  },
  "data": {
    "pqxFileName": "nicolette.bernhard",
    "sqxFileName": "nicolette.bernhard",
    "cgFileName": "nicolette.bernhard",
    "dmxFileName": "nicolette.bernhard"
  }
}
```

## 图框查询
**URL:** `http://218.94.57.151:8089/route/chart/frame`

**Type:** `GET`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 图框查询





**Request-example:**
```
curl -X GET -i http://218.94.57.151:8089/route/chart/frame
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-
└─id|int32|图框ID|-
└─ownerUnit|string|业主单位|-
└─projectName|string|工程名称|-
└─date|string|日期|-

**Response-example:**
```
{
  "code": 434,
  "resultNote": "x3u6vt",
  "resultErrorMap": {
    "mapKey": "23e4c6"
  },
  "data": {
    "id": 39,
    "ownerUnit": "m7hfvt",
    "projectName": "nicolette.bernhard",
    "date": "2022-02-22"
  }
}
```

## 图框保存
**URL:** `http://218.94.57.151:8089/route/chart/frame/save`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 图框保存




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
ownerUnit|string|业主单位|false|-
projectName|string|工程名称|false|-
date|string|日期|false|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/route/chart/frame/save --data '{
  "ownerUnit": "d2jm7k",
  "projectName": "nicolette.bernhard",
  "date": "2022-02-22"
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 64,
  "resultNote": "5yxchw",
  "resultErrorMap": {
    "mapKey": "y5oj4r"
  },
  "data": {}
}
```

