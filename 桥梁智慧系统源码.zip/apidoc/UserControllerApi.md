
# 用户管理
## 用户列表
**URL:** `http://218.94.57.151:8089/user/list`

**Type:** `POST`


**Content-Type:** `application/x-www-form-urlencoded;charset=utf-8`

**Description:** 用户列表





**Request-example:**
```
curl -X POST -i http://218.94.57.151:8089/user/list
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 505,
  "resultNote": "jmnmsc",
  "resultErrorMap": {
    "mapKey": "fvx6od"
  },
  "data": {}
}
```

## 更新密码
**URL:** `http://218.94.57.151:8089/user/updatePassword`

**Type:** `POST`


**Content-Type:** `application/json; charset=utf-8`

**Description:** 更新密码




**Body-parameters:**

Parameter|Type|Description|Required|Since
---|---|---|---|---
userId|int32|No comments found.|false|-
oldPassword|string|No comments found.|true|-
newPassword|string|No comments found.|true|-
confirmPassword|string|No comments found.|true|-

**Request-example:**
```
curl -X POST -H 'Content-Type: application/json; charset=utf-8' -i http://218.94.57.151:8089/user/updatePassword --data '{
  "userId": 267,
  "oldPassword": "kdiy2n",
  "newPassword": "er66vh",
  "confirmPassword": "ssaf90"
}'
```
**Response-fields:**

Field | Type|Description|Since
---|---|---|---
code|int32|响应结果错误码|-
resultNote|string|响应结果备注|-
resultErrorMap|map|响应结果备注|-
data|object|响应结果返回|-

**Response-example:**
```
{
  "code": 68,
  "resultNote": "vmnm2n",
  "resultErrorMap": {
    "mapKey": "43tvpq"
  },
  "data": {}
}
```

