import React, { useState, useEffect } from "react";
function Management() {
    return <div> 人员管理 </div>
}
export default Management